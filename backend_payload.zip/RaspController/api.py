#!/usr/bin/env python3

from fastapi import FastAPI, HTTPException, Depends, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from datetime import datetime
import subprocess
import json
import os
import secrets

# ---------------------------
# CONFIG
# ---------------------------
BASE_DIR = os.path.expanduser("~/RaspController")
CONFIG_FILE = os.path.join(BASE_DIR, "config.json")
TIMEOUT = 15

app = FastAPI(title="RaspController Secure API")


# ---------------------------
# LOAD / CREATE CONFIG
# ---------------------------
def load_config():
    if not os.path.exists(CONFIG_FILE):
        token = secrets.token_hex(32)

        config = {
            "api_token": token,
            "pairing_enabled": True,
            "created": datetime.utcnow().isoformat() + "Z"
        }

        os.makedirs(BASE_DIR, exist_ok=True)

        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=2)

        return config

    with open(CONFIG_FILE, "r") as f:
        return json.load(f)


def save_config(config):
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)


CONFIG = load_config()
API_TOKEN = CONFIG["api_token"]


# ---------------------------
# AUTH
# ---------------------------
def verify_token(request: Request):
    auth = request.headers.get("Authorization")

    if not auth or not auth.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="unauthorized")

    token = auth.split(" ")[1]

    if token != API_TOKEN:
        raise HTTPException(status_code=401, detail="unauthorized")

    return True


# ---------------------------
# HELPERS
# ---------------------------
def run_py(script, args=None):
    if args is None:
        args = []

    script_path = os.path.join(BASE_DIR, script)

    if not os.path.exists(script_path):
        return {"success": False, "error": "script_not_found"}

    try:
        process = subprocess.run(
            ["python3", script_path] + args,
            capture_output=True,
            text=True,
            timeout=TIMEOUT
        )

        stdout = process.stdout.strip()
        stderr = process.stderr.strip()

        if process.returncode != 0:
            return {
                "success": False,
                "error": "execution_failed",
                "stderr": stderr
            }

        if not stdout:
            return {"success": False, "error": "no_output"}

        try:
            return json.loads(stdout)
        except:
            return {
                "success": False,
                "error": "invalid_json",
                "raw": stdout
            }

    except subprocess.TimeoutExpired:
        return {"success": False, "error": "timeout"}

    except Exception as e:
        return {"success": False, "error": str(e)}


# ---------------------------
# MODELS
# ---------------------------
class CmdRequest(BaseModel):
    command: str = Field(..., min_length=1)


class GPIORequest(BaseModel):
    pin: int
    state: str


class ProcessKillRequest(BaseModel):
    pid: int


class ScriptRequest(BaseModel):
    name: str
    content: str = ""


class WOLRequest(BaseModel):
    mac: str
    ip: str | None = None
    port: int = 9


# ---------------------------
# ROOT
# ---------------------------
@app.get("/")
def root():
    return {
        "service": "RaspController API",
        "status": "running",
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }


# ---------------------------
# HEALTH CHECK
# ---------------------------
@app.get("/health")
def health():
    return {
        "status": "ok",
        "device": os.uname().nodename,
        "time": datetime.utcnow().isoformat() + "Z"
    }


# ---------------------------
# PAIRING (CONTROLLED)
# ---------------------------
@app.get("/pair")
def pair():
    if not CONFIG.get("pairing_enabled", True):
        raise HTTPException(status_code=403, detail="pairing_disabled")

    return {
        "success": True,
        "device": os.uname().nodename,
        "token": API_TOKEN,
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }


@app.post("/pair/disable")
def disable_pairing(auth=Depends(verify_token)):
    CONFIG["pairing_enabled"] = False
    save_config(CONFIG)
    return {"success": True, "pairing": "disabled"}


# ---------------------------
# COMMAND
# ---------------------------
@app.post("/cmd")
def run_command(req: CmdRequest, auth=Depends(verify_token)):
    return run_py("commands.py", [req.command])


# ---------------------------
# GPIO
# ---------------------------
@app.post("/gpio")
def gpio_control(req: GPIORequest, auth=Depends(verify_token)):
    return run_py("gpio.py", [str(req.pin), req.state.lower()])


# ---------------------------
# PROCESS
# ---------------------------
@app.get("/process/list")
def process_list(auth=Depends(verify_token)):
    return run_py("process.py", ["--list"])


@app.post("/process/kill")
def process_kill(req: ProcessKillRequest, auth=Depends(verify_token)):
    return run_py("process.py", ["--kill", str(req.pid)])


# ---------------------------
# SCRIPTS
# ---------------------------
@app.get("/script/list")
def script_list(auth=Depends(verify_token)):
    return run_py("script_manager.py", ["--list"])


@app.post("/script/run")
def script_run(req: ScriptRequest, auth=Depends(verify_token)):
    return run_py("script_manager.py", ["--run", req.name])


@app.post("/script/save")
def script_save(req: ScriptRequest, auth=Depends(verify_token)):
    return run_py("script_manager.py", ["--save", req.name, req.content])


@app.post("/script/delete")
def script_delete(req: ScriptRequest, auth=Depends(verify_token)):
    return run_py("script_manager.py", ["--delete", req.name])


# ---------------------------
# WOL
# ---------------------------
@app.post("/wol")
def wake_on_lan(req: WOLRequest, auth=Depends(verify_token)):
    args = ["--mac", req.mac]

    if req.ip:
        args += ["--ip", req.ip]

    args += ["--port", str(req.port)]

    return run_py("wol.py", args)


# ---------------------------
# MONITOR
# ---------------------------
@app.get("/monitor")
def monitor_once(auth=Depends(verify_token)):
    return run_py("monitor.py", ["--once"])


@app.get("/monitor/live")
def monitor_live(auth=Depends(verify_token)):

    def stream():
        proc = subprocess.Popen(
            ["python3", os.path.join(BASE_DIR, "monitoring_v1.py")],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True
        )
        try:
            for line in proc.stdout:
                yield line
        finally:
            proc.kill()

    return StreamingResponse(stream(), media_type="application/json")


# ---------------------------
# SYSTEM CONTROL
# ---------------------------
@app.post("/system/shutdown")
def shutdown(auth=Depends(verify_token)):
    subprocess.Popen(["sudo", "shutdown", "-h", "now"])
    return {
        "success": True,
        "action": "shutdown_sent",
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }


@app.post("/system/reboot")
def reboot(auth=Depends(verify_token)):
    subprocess.Popen(["sudo", "reboot"])
    return {
        "success": True,
        "action": "reboot_sent",
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }