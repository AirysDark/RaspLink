#!/usr/bin/env python3

import sys
import os
import json
import subprocess
import shlex
from datetime import datetime

CONF = os.path.expanduser("~/RaspController/gpio_mode.conf")
TIMEOUT = 5


# ---------------------------
# Load GPIO mode
# ---------------------------
def get_mode():
    if os.path.exists(CONF):
        try:
            with open(CONF, "r") as f:
                mode = f.read().strip()
                if mode in ["gpio", "pinctrl"]:
                    return mode
        except:
            pass

    # Auto-detect if config missing
    if shutil_which("pinctrl"):
        return "pinctrl"
    elif shutil_which("gpio"):
        return "gpio"

    return "gpio"


# ---------------------------
# Helper: check command exists
# ---------------------------
def shutil_which(cmd):
    from shutil import which
    return which(cmd) is not None


# ---------------------------
# Validate input
# ---------------------------
def validate(pin, state):
    if not pin.isdigit():
        return False, "invalid_pin"

    pin_num = int(pin)
    if pin_num < 1 or pin_num > 27:
        return False, "pin_out_of_range (1-27)"

    if state not in ["on", "off", "read"]:
        return False, "invalid_state (use on/off/read)"

    return True, None


# ---------------------------
# Execute command safely
# ---------------------------
def run(cmd):
    try:
        process = subprocess.run(
            shlex.split(cmd),
            capture_output=True,
            text=True,
            timeout=TIMEOUT
        )

        return {
            "success": process.returncode == 0,
            "returncode": process.returncode,
            "stdout": process.stdout.strip(),
            "stderr": process.stderr.strip()
        }

    except subprocess.TimeoutExpired:
        return {"success": False, "error": "timeout"}

    except FileNotFoundError:
        return {"success": False, "error": "command_not_found"}

    except Exception as e:
        return {"success": False, "error": str(e)}


# ---------------------------
# GPIO command builder
# ---------------------------
def build_command(pin, state, mode):
    if mode == "pinctrl":
        if state == "read":
            return f"pinctrl get {pin}"
        return f"pinctrl set {pin} op {'dh' if state == 'on' else 'dl'}"

    else:  # gpio (wiringPi)
        if state == "read":
            return f"gpio -g read {pin}"
        return f"gpio -g write {pin} {1 if state == 'on' else 0}"


# ---------------------------
# Main
# ---------------------------
def main():
    if len(sys.argv) < 3:
        print(json.dumps({
            "success": False,
            "error": "usage: raspgpio <pin> <on|off/read>"
        }))
        sys.exit(1)

    pin = sys.argv[1]
    state = sys.argv[2].lower()

    valid, error = validate(pin, state)
    if not valid:
        print(json.dumps({"success": False, "error": error}))
        sys.exit(1)

    mode = get_mode()
    cmd = build_command(pin, state, mode)
    result = run(cmd)

    response = {
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "pin": int(pin),
        "state": state,
        "mode": mode,
        "command": cmd,
        "result": result
    }

    print(json.dumps(response))


if __name__ == "__main__":
    main()