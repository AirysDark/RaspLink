#!/usr/bin/env python3

import os
import subprocess
import sys
from datetime import datetime

# ---------------------------
# CONFIG
# ---------------------------
HOME = os.path.expanduser("~")
INSTALL_DIR = os.path.join(HOME, "RaspController")
VENV_DIR = os.path.join(INSTALL_DIR, "venv")
SCRIPTS_DIR = os.path.join(INSTALL_DIR, "scripts")
LOG_DIR = os.path.join(INSTALL_DIR, "logs")
LOG_FILE = os.path.join(LOG_DIR, "install.log")

# ---------------------------
# LOGGING
# ---------------------------
def log(msg):
    print(msg)
    os.makedirs(LOG_DIR, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(f"{datetime.utcnow().isoformat()} {msg}\n")

# ---------------------------
# RUN COMMAND
# ---------------------------
def run(cmd, check=True):
    try:
        # If cmd is a string, run it through shell
        shell = isinstance(cmd, str)
        result = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=check,
            shell=shell
        )
        if result.stdout:
            log(result.stdout.strip())
        if result.stderr:
            log(result.stderr.strip())
        return True
    except subprocess.CalledProcessError as e:
        log(f"[ERROR] {cmd}")
        log(e.stderr)
        return False

# ---------------------------
# INSTALL APT PACKAGE
# ---------------------------
def install_if_missing(pkg):
    result = subprocess.run(
        ["dpkg", "-s", pkg],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )
    if result.returncode != 0:
        log(f"[+] Installing {pkg}...")
        run(["sudo", "apt", "install", "-y", pkg])
    else:
        log(f"[✓] {pkg} already installed")

# ---------------------------
# COPY FILE
# ---------------------------
def copy_if_exists(src):
    if os.path.isfile(src):
        dst = os.path.join(INSTALL_DIR, os.path.basename(src))
        subprocess.run(["cp", src, dst])
        log(f"[✓] Copied {os.path.basename(src)}")
    else:
        log(f"[!] Missing {os.path.basename(src)}")

# ---------------------------
# MAIN INSTALL
# ---------------------------
def main():
    log("[+] Starting installation...")

    # 1. Update apt & Install system dependencies
    log("[+] Updating package list...")
    run(["sudo", "apt", "update"])

    log("[+] Installing system packages...")
    packages = [
        "python3",
        "python3-venv",
        "python3-full",
        "i2c-tools",
        "libraspberrypi-bin",
        "net-tools",
        "curl"
    ]
    for pkg in packages:
        install_if_missing(pkg)

    # 2. Create directories
    log("[+] Creating directories...")
    os.makedirs(INSTALL_DIR, exist_ok=True)
    os.makedirs(SCRIPTS_DIR, exist_ok=True)
    os.makedirs(LOG_DIR, exist_ok=True)

    # 3. Create virtual environment (PEP 668 support)
    if not os.path.exists(VENV_DIR):
        log("[+] Creating virtual environment...")
        run(f"python3 -m venv {VENV_DIR}")
    else:
        log("[✓] venv already exists")

    # 4. Install Python packages inside venv
    log("[+] Installing Python packages in venv...")
    run(f"{VENV_DIR}/bin/pip install --upgrade pip")
    run(f"{VENV_DIR}/bin/pip install uvicorn fastapi pydantic psutil smbus2")

    # 5. Copy backend agent files
    log("[+] Copying backend agent files...")
    agent_files = [
        "agent/api.py",
        "agent/commands.py",
        "agent/gpio.py",
        "agent/monitor.py",
        "agent/monitoring_v1.py",
        "agent/process.py",
        "agent/script_manager.py",
        "agent/wol.py"
    ]
    for file in agent_files:
        copy_if_exists(file)

    # 6. Permissions
    log("[+] Setting permissions...")
    run(["chmod", "+x", os.path.join(INSTALL_DIR, "*.py")], check=False)

    # 7. Create API launcher (start_api.sh)
    log("[+] Creating API launcher...")
    start_script = os.path.join(INSTALL_DIR, "start_api.sh")
    with open(start_script, "w") as f:
        f.write(f"""#!/usr/bin/env bash
cd "{INSTALL_DIR}"
source venv/bin/activate
exec python -m uvicorn api:app --host 0.0.0.0 --port 8000
""")
    run(["chmod", "+x", start_script])
    run(["sudo", "ln", "-sf", start_script, "/usr/local/bin/raspapi"])

    # 8. Create CLI shortcuts using venv python
    log("[+] Creating command shortcuts...")
    shortcuts = {
        "raspmon": "monitoring_v1.py",
        "raspmon-once": "monitor.py",
        "raspgpio": "gpio.py",
        "raspcmd": "commands.py",
        "raspproc": "process.py",
        "raspscript": "script_manager.py",
        "raspwol": "wol.py"
    }

    for cmd, script in shortcuts.items():
        wrapper_path = os.path.join(INSTALL_DIR, f"{cmd}_wrapper.sh")
        with open(wrapper_path, "w") as f:
            f.write(f"""#!/usr/bin/env bash
"{VENV_DIR}/bin/python" "{os.path.join(INSTALL_DIR, script)}" "$@"
""")
        run(["chmod", "+x", wrapper_path])
        run(["sudo", "ln", "-sf", wrapper_path, f"/usr/local/bin/{cmd}"])

    # 9. Verify installation
    log("[+] Verifying installation...")
    if os.path.exists(f"{VENV_DIR}/bin/uvicorn"):
        log("[✓] uvicorn installed correctly")
    else:
        log("[!] uvicorn missing")

    # 10. Optional Startup Test
    log("[+] Testing API startup...")
    run(f"{VENV_DIR}/bin/python -m uvicorn agent.api:app --host 127.0.0.1 --port 8000 &", check=False)

    for cmd in list(shortcuts.keys()) + ["raspapi"]:
        result = subprocess.run(["which", cmd], stdout=subprocess.DEVNULL)
        if result.returncode == 0:
            log(f"[✓] {cmd} available")
        else:
            log(f"[!] {cmd} failed")

    log("[✓] Installation complete!")
    print("\nAPI will run on: http://<PI_IP>:8000\n")

if __name__ == "__main__":
    main()
