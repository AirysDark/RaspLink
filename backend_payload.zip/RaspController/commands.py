#!/usr/bin/env python3

import sys
import json
import subprocess
import shlex
import re
from datetime import datetime

# ---------------------------
# Config
# ---------------------------
DEFAULT_TIMEOUT = 10  # seconds
MAX_TIMEOUT = 60      # safety cap

# Hard block patterns (dangerous)
BLOCKED_PATTERNS = [
    r"rm\s+-rf\s+/",
    r"\bmkfs\b",
    r"\bdd\s+",
    r":\(\)\{",           # fork bomb
    r">\s*/dev/sd",       # disk overwrite
]

# Explicitly allowed sensitive commands
SAFE_SYSTEM_COMMANDS = [
    "shutdown",
    "reboot",
    "poweroff"
]

# Optional allowlist (set to None to disable)
ALLOWED_COMMANDS = None
# Example:
# ALLOWED_COMMANDS = ["ls", "echo", "cat", "uptime"]

SAFE_ENV = {
    "PATH": "/usr/sbin:/usr/bin:/sbin:/bin",
    "LANG": "C.UTF-8"
}


# ---------------------------
# Detect shell requirement
# ---------------------------
def needs_shell(cmd: str) -> bool:
    return any(x in cmd for x in ["&&", "|", ">", "<", "*", "$", "`"])


# ---------------------------
# Security checks
# ---------------------------
def is_blocked(cmd: str):
    cmd_lower = cmd.lower()

    # Allow safe system commands explicitly
    base_cmd = cmd_lower.strip().split(" ")[0]

    if base_cmd in SAFE_SYSTEM_COMMANDS:
        return False, None

    for pattern in BLOCKED_PATTERNS:
        if re.search(pattern, cmd_lower):
            return True, pattern

    return False, None


def is_allowed(cmd: str):
    if ALLOWED_COMMANDS is None:
        return True

    base = cmd.strip().split(" ")[0]
    return base in ALLOWED_COMMANDS


# ---------------------------
# Parse optional args
# ---------------------------
def parse_args(argv):
    timeout = DEFAULT_TIMEOUT
    raw = []

    i = 0
    while i < len(argv):
        if argv[i] == "--timeout" and i + 1 < len(argv):
            try:
                timeout = min(int(argv[i + 1]), MAX_TIMEOUT)
                i += 2
                continue
            except ValueError:
                pass
        raw.append(argv[i])
        i += 1

    cmd = " ".join(raw).strip()
    return cmd, timeout


# ---------------------------
# Execute command
# ---------------------------
def run_command(cmd: str, timeout: int):
    try:
        # Block dangerous commands
        blocked, pattern = is_blocked(cmd)
        if blocked:
            return {
                "success": False,
                "error": "blocked_command",
                "pattern": pattern
            }

        # Allowlist enforcement
        if not is_allowed(cmd):
            return {
                "success": False,
                "error": "not_allowed"
            }

        use_shell = needs_shell(cmd)

        if use_shell:
            process = subprocess.run(
                cmd,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout,
                env=SAFE_ENV
            )
        else:
            process = subprocess.run(
                shlex.split(cmd),
                capture_output=True,
                text=True,
                timeout=timeout,
                env=SAFE_ENV
            )

        return {
            "success": process.returncode == 0,
            "returncode": process.returncode,
            "stdout": process.stdout.strip(),
            "stderr": process.stderr.strip()
        }

    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "error": "timeout",
            "timeout": timeout
        }

    except FileNotFoundError:
        return {
            "success": False,
            "error": "command_not_found"
        }

    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }


# ---------------------------
# Main
# ---------------------------
def main():
    if len(sys.argv) < 2:
        print(json.dumps({
            "success": False,
            "error": "no_command"
        }))
        sys.exit(1)

    cmd, timeout = parse_args(sys.argv[1:])

    use_shell = needs_shell(cmd)
    result = run_command(cmd, timeout)

    response = {
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "command": cmd,
        "mode": "shell" if use_shell else "safe_exec",
        "timeout": timeout,
        "result": result
    }

    print(json.dumps(response))


if __name__ == "__main__":
    main()