#!/usr/bin/env python3

import json
import time
import subprocess
import psutil
import platform
import shlex
from datetime import datetime

INTERVAL = 1.0
TIMEOUT = 3

# ---------------------------
# Safe command execution
# ---------------------------
def safe_cmd(cmd):
    try:
        process = subprocess.run(
            shlex.split(cmd),
            capture_output=True,
            text=True,
            timeout=TIMEOUT
        )
        return process.stdout.strip()
    except:
        return None


# ---------------------------
# Temperature detection
# ---------------------------
def get_temp():
    out = safe_cmd("vcgencmd measure_temp")
    if out and "temp=" in out:
        try:
            return float(out.split("=")[1].split("'")[0])
        except:
            pass

    out = safe_cmd("cat /sys/class/thermal/thermal_zone0/temp")
    if out and out.isdigit():
        return round(int(out) / 1000.0, 2)

    return None


# ---------------------------
# CPU frequency
# ---------------------------
def get_cpu_freq():
    try:
        freq = psutil.cpu_freq()
        return {
            "current": freq.current if freq else None,
            "min": freq.min if freq else None,
            "max": freq.max if freq else None
        }
    except:
        return {
            "current": None,
            "min": None,
            "max": None
        }


# ---------------------------
# Disk info (multi-mount)
# ---------------------------
def get_disks():
    disks = []
    try:
        partitions = psutil.disk_partitions(all=False)
        for p in partitions:
            try:
                usage = psutil.disk_usage(p.mountpoint)
                disks.append({
                    "mountpoint": p.mountpoint,
                    "fstype": p.fstype,
                    "percent": usage.percent,
                    "total": usage.total,
                    "used": usage.used,
                    "free": usage.free
                })
            except:
                continue
    except:
        pass

    return disks


# ---------------------------
# Network speed tracker
# ---------------------------
_prev_net = None
_prev_time = None


def get_network():
    global _prev_net, _prev_time

    net = psutil.net_io_counters()
    now = time.time()

    speed_rx = 0.0
    speed_tx = 0.0

    if _prev_net is not None:
        delta = now - _prev_time
        if delta > 0:
            speed_rx = (net.bytes_recv - _prev_net.bytes_recv) / delta
            speed_tx = (net.bytes_sent - _prev_net.bytes_sent) / delta

    _prev_net = net
    _prev_time = now

    return {
        "bytes_sent": net.bytes_sent,
        "bytes_recv": net.bytes_recv,
        "packets_sent": net.packets_sent,
        "packets_recv": net.packets_recv,
        "errin": net.errin,
        "errout": net.errout,
        "speed_rx_kbs": round(speed_rx / 1024, 2),
        "speed_tx_kbs": round(speed_tx / 1024, 2)
    }


# ---------------------------
# System snapshot
# ---------------------------
def snapshot():
    try:
        vm = psutil.virtual_memory()

        return {
            "timestamp": datetime.utcnow().isoformat() + "Z",

            "system": {
                "hostname": platform.node(),
                "platform": platform.system()
            },

            "cpu": {
                "percent": psutil.cpu_percent(interval=0.2),
                "cores": psutil.cpu_count(),
                "frequency": get_cpu_freq()
            },

            "memory": {
                "percent": vm.percent,
                "total": vm.total,
                "used": vm.used,
                "available": vm.available,
                "free": vm.free
            },

            "disks": get_disks(),

            "network": get_network(),

            "temperature_c": get_temp()
        }

    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }


# ---------------------------
# Main loop
# ---------------------------
def main():
    while True:
        try:
            print(json.dumps(snapshot()), flush=True)
            time.sleep(max(0.2, INTERVAL))
        except KeyboardInterrupt:
            break


if __name__ == "__main__":
    main()