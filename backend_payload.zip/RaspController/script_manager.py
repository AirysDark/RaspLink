#!/usr/bin/env python3

import os
import json
import subprocess
import argparse
import re
from datetime import datetime

# ---------------------------
# Config
# ---------------------------
BASE_DIR = os.path.expanduser("~/RaspController/scripts")
TIMEOUT = 15

# Ensure scripts directory exists
os.makedirs(BASE_DIR, exist_ok=True)


# ---------------------------
# Security Helpers
# ---------------------------
def sanitize_name(name):
    """
    Only allow safe filenames: letters, numbers, underscore
    Prevent path traversal and injection
    """
    if not re.match(r'^[a-zA-Z0-9_\-]+$', name):
        return None
    return name


def script_path(name):
    return os.path.join(BASE_DIR, f"{name}.py")


# ---------------------------
# Save Script
# ---------------------------
def save_script(name, content):
    name = sanitize_name(name)
    if not name:
        return {"success": False, "error": "invalid_name"}

    path = script_path(name)

    try:
        with open(path, "w") as f:
            f.write(content)

        os.chmod(path, 0o755)

        return {
            "success": True,
            "action": "saved",
            "script": name,
            "path": path
        }

    except Exception as e:
        return {"success": False, "error": str(e)}


# ---------------------------
# Run Script
# ---------------------------
def run_script(name):
    name = sanitize_name(name)
    if not name:
        return {"success": False, "error": "invalid_name"}

    path = script_path(name)

    if not os.path.exists(path):
        return {"success": False, "error": "script_not_found"}

    try:
        process = subprocess.run(
            ["python3", path],
            capture_output=True,
            text=True,
            timeout=TIMEOUT
        )

        stdout = process.stdout.strip()
        stderr = process.stderr.strip()

        # Try JSON parse
        parsed = None
        try:
            parsed = json.loads(stdout)
        except:
            pass

        return {
            "success": process.returncode == 0,
            "returncode": process.returncode,
            "stdout": stdout,
            "stderr": stderr,
            "parsed": parsed
        }

    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "error": "timeout",
            "timeout": TIMEOUT
        }

    except Exception as e:
        return {"success": False, "error": str(e)}


# ---------------------------
# List Scripts
# ---------------------------
def list_scripts():
    try:
        scripts = []

        for file in os.listdir(BASE_DIR):
            if file.endswith(".py"):
                path = os.path.join(BASE_DIR, file)

                scripts.append({
                    "name": file.replace(".py", ""),
                    "path": path,
                    "size": os.path.getsize(path),
                    "modified": datetime.utcfromtimestamp(
                        os.path.getmtime(path)
                    ).isoformat() + "Z"
                })

        return {
            "success": True,
            "count": len(scripts),
            "scripts": scripts
        }

    except Exception as e:
        return {"success": False, "error": str(e)}


# ---------------------------
# Delete Script
# ---------------------------
def delete_script(name):
    name = sanitize_name(name)
    if not name:
        return {"success": False, "error": "invalid_name"}

    path = script_path(name)

    if not os.path.exists(path):
        return {"success": False, "error": "script_not_found"}

    try:
        os.remove(path)

        return {
            "success": True,
            "action": "deleted",
            "script": name
        }

    except Exception as e:
        return {"success": False, "error": str(e)}


# ---------------------------
# Read Script (for editing)
# ---------------------------
def read_script(name):
    name = sanitize_name(name)
    if not name:
        return {"success": False, "error": "invalid_name"}

    path = script_path(name)

    if not os.path.exists(path):
        return {"success": False, "error": "script_not_found"}

    try:
        with open(path, "r") as f:
            content = f.read()

        return {
            "success": True,
            "script": name,
            "content": content
        }

    except Exception as e:
        return {"success": False, "error": str(e)}


# ---------------------------
# Main CLI Interface
# ---------------------------
def main():
    parser = argparse.ArgumentParser(description="Script Manager")

    parser.add_argument("--save", type=str, help="Save script (name)")
    parser.add_argument("--content", type=str, help="Script content")

    parser.add_argument("--run", type=str, help="Run script")
    parser.add_argument("--list", action="store_true", help="List scripts")
    parser.add_argument("--delete", type=str, help="Delete script")
    parser.add_argument("--read", type=str, help="Read script")

    args = parser.parse_args()

    # Save
    if args.save:
        if not args.content:
            print(json.dumps({
                "success": False,
                "error": "missing_content"
            }))
            return

        result = save_script(args.save, args.content)

    # Run
    elif args.run:
        result = run_script(args.run)

    # List
    elif args.list:
        result = list_scripts()

    # Delete
    elif args.delete:
        result = delete_script(args.delete)

    # Read
    elif args.read:
        result = read_script(args.read)

    else:
        result = {
            "success": False,
            "error": "no_action"
        }

    print(json.dumps({
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "result": result
    }))


if __name__ == "__main__":
    main()