#!/usr/bin/env python3

import json
import psutil
import time
import argparse
from datetime import datetime

# ---------------------------
# Config
# ---------------------------
SAFE_MODE = True
CPU_SAMPLE_INTERVAL = 0.2  # ensures accurate CPU readings


# ---------------------------
# Helpers
# ---------------------------
def format_bytes(b):
    try:
        return round(b / (1024 * 1024), 2)  # MB
    except:
        return 0.0


def get_cpu_time(proc):
    try:
        t = proc.cpu_times()
        total = t.user + t.system
        return time.strftime("%H:%M:%S", time.gmtime(total))
    except:
        return "00:00:00"


def is_critical(pid, name):
    if not SAFE_MODE:
        return False

    if pid == 1:
        return True

    critical_prefixes = [
        "init", "systemd", "kthreadd", "rcu_", "migration",
        "kworker", "sshd"
    ]

    return any(name.startswith(p) for p in critical_prefixes)


# ---------------------------
# Process collection
# ---------------------------
def collect_processes():
    processes = []

    # First pass (prime CPU counters)
    for proc in psutil.process_iter():
        try:
            proc.cpu_percent(None)
        except:
            pass

    time.sleep(CPU_SAMPLE_INTERVAL)

    # Second pass (real values)
    for proc in psutil.process_iter([
        "pid", "username", "name", "memory_percent", "nice", "status"
    ]):
        try:
            mem = proc.memory_info()

            processes.append({
                "pid": proc.info.get("pid"),
                "user": proc.info.get("username"),
                "priority": proc.nice(),
                "nice": proc.info.get("nice"),
                "memory": {
                    "virtual": format_bytes(mem.vms),
                    "physical": format_bytes(mem.rss),
                    "shared": format_bytes(getattr(mem, "shared", 0))
                },
                "status": proc.info.get("status"),
                "cpu_percent": proc.cpu_percent(None),
                "ram_percent": round(proc.info.get("memory_percent", 0.0), 2),
                "time": get_cpu_time(proc),
                "command": proc.info.get("name")
            })

        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
        except Exception:
            continue

    return processes


# ---------------------------
# Sorting
# ---------------------------
def sort_processes(processes, sort_by="cpu", order="desc"):
    key_map = {
        "cpu": "cpu_percent",
        "ram": "ram_percent",
        "pid": "pid",
        "name": "command"
    }

    key = key_map.get(sort_by, "cpu_percent")
    reverse = (order == "desc")

    try:
        processes.sort(key=lambda x: x.get(key, 0), reverse=reverse)
    except:
        pass

    return processes


# ---------------------------
# Kill process
# ---------------------------
def kill_process(pid):
    try:
        pid = int(pid)
        proc = psutil.Process(pid)
        name = proc.name()

        if is_critical(pid, name):
            return {
                "success": False,
                "error": "protected_process"
            }

        proc.terminate()

        try:
            proc.wait(timeout=3)
            return {
                "success": True,
                "action": "terminated",
                "pid": pid
            }
        except psutil.TimeoutExpired:
            proc.kill()
            return {
                "success": True,
                "action": "killed",
                "pid": pid
            }

    except psutil.NoSuchProcess:
        return {"success": False, "error": "process_not_found"}

    except psutil.AccessDenied:
        return {"success": False, "error": "access_denied"}

    except Exception as e:
        return {"success": False, "error": str(e)}


# ---------------------------
# Main
# ---------------------------
def main():
    parser = argparse.ArgumentParser(description="Process Manager")
    parser.add_argument("--list", action="store_true", help="List processes")
    parser.add_argument("--kill", type=int, help="Kill process by PID")
    parser.add_argument("--sort", default="cpu", help="cpu | ram | pid | name")
    parser.add_argument("--order", default="desc", help="asc | desc")
    args = parser.parse_args()

    # Kill mode
    if args.kill is not None:
        result = kill_process(args.kill)

        print(json.dumps({
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "action": "kill",
            "result": result
        }))
        return

    # List mode (default)
    processes = collect_processes()
    processes = sort_processes(processes, args.sort, args.order)

    print(json.dumps({
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "count": len(processes),
        "processes": processes
    }))


if __name__ == "__main__":
    main()