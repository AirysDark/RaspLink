#!/usr/bin/env python3

import sys
import json
import socket
import argparse
import ipaddress
import time
from datetime import datetime

DEFAULT_PORT = 9
SEND_COUNT = 3       # send multiple times for reliability
SEND_DELAY = 0.1     # seconds between sends


# ---------------------------
# Validate and normalize MAC
# ---------------------------
def normalize_mac(mac: str) -> bytes:
    mac = mac.strip().lower().replace("-", "").replace(":", "").replace(".", "")

    if len(mac) != 12 or not all(c in "0123456789abcdef" for c in mac):
        raise ValueError("invalid_mac")

    return bytes.fromhex(mac)


# ---------------------------
# Validate IP / broadcast
# ---------------------------
def resolve_target_ip(ip: str | None) -> str:
    if not ip:
        return "255.255.255.255"

    try:
        # Allow both single IP and subnet (e.g., 192.168.1.0/24)
        if "/" in ip:
            network = ipaddress.ip_network(ip, strict=False)
            return str(network.broadcast_address)
        else:
            ipaddress.ip_address(ip)
            return ip
    except Exception:
        raise ValueError("invalid_ip")


# ---------------------------
# Create magic packet
# ---------------------------
def create_magic_packet(mac_bytes: bytes) -> bytes:
    return b"\xff" * 6 + mac_bytes * 16


# ---------------------------
# Send WOL packet
# ---------------------------
def send_wol(mac: str, ip: str = None, port: int = DEFAULT_PORT):
    start_time = time.time()

    try:
        mac_bytes = normalize_mac(mac)
        target_ip = resolve_target_ip(ip)
        packet = create_magic_packet(mac_bytes)

        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.settimeout(2)

        sent_packets = 0

        for _ in range(SEND_COUNT):
            sock.sendto(packet, (target_ip, port))
            sent_packets += 1
            time.sleep(SEND_DELAY)

        sock.close()

        duration = round((time.time() - start_time) * 1000, 2)

        return {
            "success": True,
            "mac": mac,
            "target_ip": target_ip,
            "port": port,
            "packets_sent": sent_packets,
            "duration_ms": duration
        }

    except ValueError as ve:
        return {
            "success": False,
            "error": str(ve)
        }

    except socket.timeout:
        return {
            "success": False,
            "error": "network_timeout"
        }

    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }


# ---------------------------
# Main
# ---------------------------
def main():
    parser = argparse.ArgumentParser(description="Wake-on-LAN sender")
    parser.add_argument("--mac", required=True, help="Target MAC address")
    parser.add_argument("--ip", help="Target IP or subnet (optional)")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT, help="Port (default 9)")

    args = parser.parse_args()

    result = send_wol(args.mac, args.ip, args.port)

    response = {
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "action": "wake_on_lan",
        "result": result
    }

    print(json.dumps(response))


if __name__ == "__main__":
    main()